// Synthesi - Composition
package ergastirio7.2;

public class Mihani {

	private int kyvismos;
	private int ippodynami;

    // Initialize object with null values
    public Mihani() {
    }
    // Initialize object with given values
    public Mihani(String new_kyvismos, String new_ippodynami) {
        this(new_kyvismos, new_ippodynami);
    }

    public void leitourgia() {
        
    }

    public void kinisi() {
        
    }

    public void svysimo() {
        
    }

    // Get-Set Kyvismos
    public int getKyvismos() {
        return this.kyvismos;
    }
    public void setKyvismos(int new_kyvismos) {
        this.kyvismos = new_kyvismos;
    }
    // Get-Set Ippodynami
    public int getIppodynami() {
        return this.ippodynami;
    }
    public void setIppodynami(int new_ippodynami) {
        this.ippodynami = new_ippodynami;
    }

}
