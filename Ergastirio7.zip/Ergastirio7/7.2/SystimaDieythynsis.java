// Synthesi - Composition
package ergastirio7.2;

public class SystimaDieythynsis {
    // Initialize object with null values
    public SystimaDieythynsis() {
    }

    public void vazeiEmpros() {
        
    }

    public void svynei() {
        
    }

    public void striveiAristera() {
        
    }

    public void striveiDexia() {
        
    }

}